import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";

import { Colors } from "@/theme/colors";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";
import CalendarFooter from "./CalendarFooter";
import CalendarGrid from "./CalendarGrid";
import CalendarHeader from "./CalendarHeader";
import {
    DatePreset,
    DateRange,
    formatMonthDay,
    rangeForPreset,
    startOfDay,
} from "./calendarUtils";

type CalendarProps = {
  range: DateRange;
  preset?: DatePreset;
  onApply: (range: DateRange, preset: DatePreset) => void;
};

export default function Calendar({
  range,
  preset = "custom",
  onApply,
}: CalendarProps) {
  const [selectedStart, setSelectedStart] = useState<Date>(range.start);
  const [selectedEnd, setSelectedEnd] = useState<Date>(range.end);
  const [activePreset, setActivePreset] = useState<DatePreset>(preset);

  // Month & year for FROM calendar
  const [fromMonth, setFromMonth] = useState<number>(range.start.getMonth());
  const [fromYear, setFromYear] = useState<number>(range.start.getFullYear());

  // Month & year for TO calendar
  const [toMonth, setToMonth] = useState<number>(range.end.getMonth());
  const [toYear, setToYear] = useState<number>(range.end.getFullYear());

  const handlePrevFromMonth = () => {
    if (fromMonth === 0) {
      setFromMonth(11);
      setFromYear((y) => y - 1);
    } else {
      setFromMonth((m) => m - 1);
    }
  };

  const handleNextFromMonth = () => {
    if (fromMonth === 11) {
      setFromMonth(0);
      setFromYear((y) => y + 1);
    } else {
      setFromMonth((m) => m + 1);
    }
  };

  const handlePrevToMonth = () => {
    if (toMonth === 0) {
      setToMonth(11);
      setToYear((y) => y - 1);
    } else {
      setToMonth((m) => m - 1);
    }
  };

  const handleNextToMonth = () => {
    if (toMonth === 11) {
      setToMonth(0);
      setToYear((y) => y + 1);
    } else {
      setToMonth((m) => m + 1);
    }
  };

  const handleSelectStartDate = (date: Date) => {
    const newStart = startOfDay(date);
    setSelectedStart(newStart);
    setActivePreset("custom");

    // If start date is after end date, adjust end date
    if (newStart.getTime() > selectedEnd.getTime()) {
      setSelectedEnd(newStart);
    }
  };

  const handleSelectEndDate = (date: Date) => {
    const newEnd = startOfDay(date);
    setSelectedEnd(newEnd);
    setActivePreset("custom");

    // If end date is before start date, adjust start date
    if (newEnd.getTime() < selectedStart.getTime()) {
      setSelectedStart(newEnd);
    }
  };

  const handleSelectPreset = (newPreset: DatePreset) => {
    setActivePreset(newPreset);
    const resolved = rangeForPreset(newPreset, {
      start: selectedStart,
      end: selectedEnd,
    });
    setSelectedStart(resolved.start);
    setSelectedEnd(resolved.end);
    setFromMonth(resolved.start.getMonth());
    setFromYear(resolved.start.getFullYear());
    setToMonth(resolved.end.getMonth());
    setToYear(resolved.end.getFullYear());
  };

  const handleApply = () => {
    onApply(
      {
        start: selectedStart,
        end: selectedEnd,
      },
      activePreset,
    );
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.calendarsRow}>
        {/* FROM Calendar Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>FROM :</Text>

          <CalendarHeader
            currentMonth={fromMonth}
            currentYear={fromYear}
            onPrevMonth={handlePrevFromMonth}
            onNextMonth={handleNextFromMonth}
            onSelectMonth={setFromMonth}
            onSelectYear={setFromYear}
          />

          <CalendarGrid
            year={fromYear}
            month={fromMonth}
            startDate={selectedStart}
            endDate={selectedEnd}
            onSelectDate={handleSelectStartDate}
          />

          <View style={styles.summaryBadge}>
            <Text style={styles.summaryLabel}>From Date</Text>
            <Text style={styles.summaryValue}>
              {formatMonthDay(selectedStart)}
            </Text>
          </View>
        </View>

        {/* Middle Arrow */}
        <View style={styles.arrowContainer}>
          <Ionicons name="arrow-forward" size={18} color={Colors.mainColour1} />
        </View>

        {/* TO Calendar Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>TO :</Text>

          <CalendarHeader
            currentMonth={toMonth}
            currentYear={toYear}
            onPrevMonth={handlePrevToMonth}
            onNextMonth={handleNextToMonth}
            onSelectMonth={setToMonth}
            onSelectYear={setToYear}
          />

          <CalendarGrid
            year={toYear}
            month={toMonth}
            startDate={selectedStart}
            endDate={selectedEnd}
            onSelectDate={handleSelectEndDate}
          />

          <View style={styles.summaryBadge}>
            <Text style={styles.summaryLabel}>To Date</Text>
            <Text style={styles.summaryValue}>
              {formatMonthDay(selectedEnd)}
            </Text>
          </View>
        </View>
      </View>

      {/* Footer Info Banner, Presets, and Apply Action */}
      <CalendarFooter
        startDate={selectedStart}
        endDate={selectedEnd}
        activePreset={activePreset}
        onSelectPreset={handleSelectPreset}
        onApply={handleApply}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    maxHeight: 560,
  },
  content: {
    padding: 14,
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
  },
  calendarsRow: {
    flexDirection: "column",
    gap: 12,
  },
  arrowContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 2,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1.2,
    borderColor: "#E5E7EB",
    padding: 12,
    ...Shadows.card,
  },
  cardTitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  summaryBadge: {
    marginTop: 10,
    backgroundColor: "#EFF6FF",
    borderRadius: Radius.lg,
    paddingVertical: 7,
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  summaryLabel: {
    fontSize: 11,
    color: "#374151",
  },
  summaryValue: {
    fontSize: 12,
    color: Colors.mainColour1,
    fontWeight: "700",
  },
});
