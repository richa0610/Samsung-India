import { StyleSheet, Text, View } from "react-native";
import CalendarDay from "./CalendarDay";
import {
    WEEKDAYS,
    generateMonthGrid,
    isBetweenDates,
    isSameDay,
} from "./calendarUtils";

type CalendarGridProps = {
  year: number;
  month: number;
  startDate: Date | null;
  endDate: Date | null;
  onSelectDate: (date: Date) => void;
};

export default function CalendarGrid({
  year,
  month,
  startDate,
  endDate,
  onSelectDate,
}: CalendarGridProps) {
  const days = generateMonthGrid(year, month);

  return (
    <View style={styles.container}>
      {/* Weekday Row */}
      <View style={styles.weekdaysRow}>
        {WEEKDAYS.map((weekday) => (
          <Text key={weekday} style={styles.weekdayLabel}>
            {weekday}
          </Text>
        ))}
      </View>

      {/* Days Grid */}
      <View style={styles.grid}>
        {days.map((item, index) => {
          const isStart = isSameDay(item.date, startDate);
          const isEnd = isSameDay(item.date, endDate);
          const inRange = isBetweenDates(item.date, startDate, endDate);

          return (
            <CalendarDay
              key={`${item.date.toISOString()}-${index}`}
              date={item.date}
              dayNumber={item.dayNumber}
              isCurrentMonth={item.isCurrentMonth}
              isStart={isStart}
              isEnd={isEnd}
              isInRange={inRange}
              onSelect={onSelectDate}
            />
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  weekdaysRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
    paddingHorizontal: 2,
  },
  weekdayLabel: {
    width: 32,
    textAlign: "center",
    fontSize: 10,
    color: "#6B7280",
    fontWeight: "500",
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
});
