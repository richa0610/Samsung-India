import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import {
    Modal,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

import { Colors } from "@/theme/colors";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";
import { MONTH_NAMES } from "./calendarUtils";

type MonthSelectorProps = {
  currentMonth: number;
  currentYear: number;
  onSelectMonth: (month: number) => void;
  onSelectYear: (year: number) => void;
};

export default function MonthSelector({
  currentMonth,
  currentYear,
  onSelectMonth,
  onSelectYear,
}: MonthSelectorProps) {
  const [pickerMode, setPickerMode] = useState<"month" | "year" | null>(null);

  const years = Array.from({ length: 11 }, (_, i) => currentYear - 5 + i);

  return (
    <View style={styles.container}>
      <Pressable
        style={styles.dropdownPill}
        onPress={() => setPickerMode("month")}
      >
        <Text style={styles.dropdownPillText}>{MONTH_NAMES[currentMonth]}</Text>
        <Ionicons name="chevron-down" size={12} color="#6B7280" />
      </Pressable>

      <Pressable
        style={styles.dropdownPill}
        onPress={() => setPickerMode("year")}
      >
        <Text style={styles.dropdownPillText}>{currentYear}</Text>
        <Ionicons name="chevron-down" size={12} color="#6B7280" />
      </Pressable>

      {/* Month / Year Picker Modal */}
      <Modal
        visible={pickerMode !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setPickerMode(null)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setPickerMode(null)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {pickerMode === "month" ? "Select Month" : "Select Year"}
            </Text>

            <ScrollView
              style={styles.modalList}
              showsVerticalScrollIndicator={false}
            >
              {pickerMode === "month" &&
                MONTH_NAMES.map((name, index) => {
                  const isSelected = currentMonth === index;
                  return (
                    <Pressable
                      key={name}
                      style={[
                        styles.modalOption,
                        isSelected && styles.modalOptionSelected,
                      ]}
                      onPress={() => {
                        onSelectMonth(index);
                        setPickerMode(null);
                      }}
                    >
                      <Text
                        style={[
                          styles.modalOptionText,
                          isSelected && styles.modalOptionTextSelected,
                        ]}
                      >
                        {name}
                      </Text>
                      {isSelected && (
                        <Ionicons
                          name="checkmark"
                          size={16}
                          color={Colors.mainColour1}
                        />
                      )}
                    </Pressable>
                  );
                })}

              {pickerMode === "year" &&
                years.map((year) => {
                  const isSelected = currentYear === year;
                  return (
                    <Pressable
                      key={year}
                      style={[
                        styles.modalOption,
                        isSelected && styles.modalOptionSelected,
                      ]}
                      onPress={() => {
                        onSelectYear(year);
                        setPickerMode(null);
                      }}
                    >
                      <Text
                        style={[
                          styles.modalOptionText,
                          isSelected && styles.modalOptionTextSelected,
                        ]}
                      >
                        {year}
                      </Text>
                      {isSelected && (
                        <Ionicons
                          name="checkmark"
                          size={16}
                          color={Colors.mainColour1}
                        />
                      )}
                    </Pressable>
                  );
                })}
            </ScrollView>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  dropdownPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: Colors.white,
    borderWidth: 1.2,
    borderColor: "#D1D5DB",
    borderRadius: Radius.md,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  dropdownPillText: {
    fontSize: 11,
    color: "#1F2937",
    fontWeight: "500",
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  modalCard: {
    width: "80%",
    maxWidth: 300,
    maxHeight: 360,
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    padding: 16,
    ...Shadows.raised,
  },
  modalTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
    textAlign: "center",
  },
  modalList: {
    maxHeight: 280,
  },
  modalOption: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: Radius.md,
  },
  modalOptionSelected: {
    backgroundColor: "#EFF6FF",
  },
  modalOptionText: {
    fontSize: 13,
    color: "#374151",
  },
  modalOptionTextSelected: {
    color: Colors.mainColour1,
    fontWeight: "700",
  },
});
