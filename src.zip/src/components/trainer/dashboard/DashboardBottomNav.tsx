import { Pressable, StyleSheet, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";

import AppText from "@/components/ui/AppText";
import { Colors } from "@/theme/colors";
import { Fonts } from "@/theme/fonts";
import { FontWeight } from "@/theme/fontWeight";
import { Shadows } from "@/theme/shadows";

type TabKey = "home" | "plan" | "profile" | "more";

type DashboardBottomNavProps = {
  activeTab?: TabKey;
  onSelectTab: (tab: TabKey) => void;
};

export default function DashboardBottomNav({
  activeTab = "home",
  onSelectTab,
}: DashboardBottomNavProps) {
  const tabs = [
    {
      key: "home" as const,
      label: "Home",
      iconActive: "home" as const,
      iconInactive: "home-outline" as const,
    },
    {
      key: "plan" as const,
      label: "Plan",
      iconActive: "calendar" as const,
      iconInactive: "calendar-outline" as const,
    },
    {
      key: "profile" as const,
      label: "Profile",
      iconActive: "person-circle" as const,
      iconInactive: "person-circle-outline" as const,
    },
    {
      key: "more" as const,
      label: "More",
      iconActive: "apps" as const,
      iconInactive: "apps-outline" as const,
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <View style={styles.navBar}>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          const color = isActive ? Colors.mainColour1 : "#6B7280";

          return (
            <Pressable
              key={tab.key}
              style={styles.tabButton}
              onPress={() => onSelectTab(tab.key)}
              accessibilityRole="button"
              accessibilityState={{ selected: isActive }}
              accessibilityLabel={tab.label}
            >
              <Ionicons
                name={isActive ? tab.iconActive : tab.iconInactive}
                size={22}
                color={color}
              />
              <AppText
                style={[styles.tabLabel, { color }]}
                weight={isActive ? FontWeight.semiBold : FontWeight.regular}
              >
                {tab.label}
              </AppText>
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    ...Shadows.footer,
  },
  navBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: "#F3F4F6",
  },
  tabButton: {
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
    paddingVertical: 4,
    minWidth: 60,
  },
  tabLabel: {
    fontSize: 10,
  },
});
