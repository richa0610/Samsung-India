import { Pressable, StyleSheet, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import AppText from "@/components/ui/AppText";
import { DatePreset } from "@/components/trainer/DateDrop";
import { PRESET_LABELS, formatDisplayDate } from "./dashboardUtils";
import { Colors } from "@/theme/colors";
import { FontWeight } from "@/theme/fontWeight";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";

type DateRangeSelectorProps = {
  startDate: Date;
  endDate: Date;
  preset: DatePreset;
  onOpenDateDrop: () => void;
};

export default function DateRangeSelector({
  startDate,
  endDate,
  preset,
  onOpenDateDrop,
}: DateRangeSelectorProps) {
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <Pressable
          style={styles.dateBox}
          onPress={onOpenDateDrop}
          accessibilityRole="button"
          accessibilityLabel="Start Date"
        >
          <Ionicons
            name="calendar-outline"
            size={16}
            color={Colors.mainColour1}
          />
          <AppText style={styles.dateBoxText} weight={FontWeight.medium}>
            {formatDisplayDate(startDate)}
          </AppText>
        </Pressable>

        <Ionicons name="arrow-forward" size={16} color={Colors.gray400} />

        <Pressable
          style={styles.dateBox}
          onPress={onOpenDateDrop}
          accessibilityRole="button"
          accessibilityLabel="End Date"
        >
          <Ionicons
            name="calendar-outline"
            size={16}
            color={Colors.mainColour1}
          />
          <AppText style={styles.dateBoxText} weight={FontWeight.medium}>
            {formatDisplayDate(endDate)}
          </AppText>
        </Pressable>

        <Pressable
          style={styles.presetButton}
          onPress={onOpenDateDrop}
          accessibilityRole="button"
          accessibilityLabel="Date Preset"
        >
          <Ionicons name="calendar-outline" size={16} color={Colors.white} />
          <AppText
            style={styles.presetButtonText}
            color={Colors.white}
            weight={FontWeight.medium}
          >
            {PRESET_LABELS[preset] ?? "This Month"}
          </AppText>
          <Ionicons name="chevron-down" size={14} color={Colors.white} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 2,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  dateBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    backgroundColor: Colors.white,
    borderWidth: 1.2,
    borderColor: "#D1D5DB",
    borderRadius: Radius.lg,
    paddingHorizontal: 8,
    paddingVertical: 9,
    ...Shadows.card,
  },
  dateBoxText: {
    fontSize: 11,
    color: "#374151",
  },
  presetButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
    backgroundColor: Colors.mainColour1,
    borderRadius: Radius.lg,
    paddingHorizontal: 10,
    paddingVertical: 10,
    ...Shadows.card,
  },
  presetButtonText: {
    fontSize: 11,
  },
});
