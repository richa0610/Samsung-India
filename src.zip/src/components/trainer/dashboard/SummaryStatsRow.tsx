import { Ionicons } from "@expo/vector-icons";
import { StyleSheet, View } from "react-native";

import StatCard from "./StatCard";
import { DashboardStats } from "./dashboardUtils";

type SummaryStatsRowProps = {
  stats: DashboardStats;
};

export default function SummaryStatsRow({ stats }: SummaryStatsRowProps) {
  return (
    <View style={styles.container}>
      <StatCard
        icon={<Ionicons name="people" size={20} color="#2563EB" />}
        iconBg="#DBEAFE"
        title="Total Trainees"
        value={stats.totalTrainees}
        valueColor="#2563EB"
        subtext="All Active"
        isActive={true}
      />

      <StatCard
        icon={<Ionicons name="book-outline" size={19} color="#10B981" />}
        iconBg="#D1FAE5"
        title="Total Sessions"
        value={stats.totalSessions}
        valueColor="#10B981"
        subtext="This Period"
      />

      <StatCard
        icon={<Ionicons name="calendar-outline" size={19} color="#F59E0B" />}
        iconBg="#FEF3C7"
        title="Completed"
        value={stats.completed}
        valueColor="#F59E0B"
        subtext="This Period"
      />

      <StatCard
        icon={<Ionicons name="time-outline" size={19} color="#EF4444" />}
        iconBg="#FEE2E2"
        title="Pending"
        value={stats.pending}
        valueColor="#EF4444"
        subtext="This Period"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    marginTop: 10,
  },
});
