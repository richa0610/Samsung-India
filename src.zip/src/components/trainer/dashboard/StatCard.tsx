import { ReactNode } from "react";
import { StyleSheet, View } from "react-native";

import AppText from "@/components/ui/AppText";
import { Colors } from "@/theme/colors";
import { Fonts } from "@/theme/fonts";
import { FontWeight } from "@/theme/fontWeight";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";

type StatCardProps = {
  icon: ReactNode;
  iconBg: string;
  title: string;
  value: string | number;
  valueColor: string;
  subtext: string;
  isActive?: boolean;
};

export default function StatCard({
  icon,
  iconBg,
  title,
  value,
  valueColor,
  subtext,
  isActive = false,
}: StatCardProps) {
  return (
    <View style={[styles.card, isActive && styles.cardActive]}>
      <View style={[styles.iconCircle, { backgroundColor: iconBg }]}>
        {icon}
      </View>
      <AppText style={styles.title} color={Colors.gray600} numberOfLines={1}>
        {title}
      </AppText>
      <AppText style={[styles.value, { color: valueColor }]} weight={FontWeight.bold}>
        {value}
      </AppText>
      <AppText style={styles.subtext} color={Colors.gray400} numberOfLines={1}>
        {subtext}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    paddingVertical: 14,
    paddingHorizontal: 6,
    alignItems: "center",
    justifyContent: "space-between",
    minHeight: 130,
    borderWidth: 1.5,
    borderColor: "transparent",
    ...Shadows.card,
  },
  cardActive: {
    borderColor: Colors.mainColour1,
  },
  iconCircle: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 6,
  },
  title: {
    fontSize: 10,
    textAlign: "center",
    marginBottom: 4,
  },
  value: {
    fontSize: 18,
    textAlign: "center",
    marginBottom: 2,
  },
  subtext: {
    fontSize: 9,
    textAlign: "center",
  },
});
