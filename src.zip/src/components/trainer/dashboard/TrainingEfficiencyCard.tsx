import { Pressable, StyleSheet, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import AppText from "@/components/ui/AppText";
import { DonutChart } from "@/components/trainer/charts";
import { DashboardStats } from "./dashboardUtils";
import { Colors } from "@/theme/colors";
import { Fonts } from "@/theme/fonts";
import { FontWeight } from "@/theme/fontWeight";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";

type TrainingEfficiencyCardProps = {
  stats: DashboardStats;
  onOverviewPress?: () => void;
};

export default function TrainingEfficiencyCard({
  stats,
  onOverviewPress,
}: TrainingEfficiencyCardProps) {
  const {
    totalSessions,
    completed,
    pending,
    executedPercentage,
    pendingPercentage,
  } = stats;

  const donutSegments = [
    { label: "Executed", value: completed, color: "#10B981" },
    { label: "Pending", value: pending, color: "#2563EB" },
  ];

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <AppText style={styles.title} weight={FontWeight.semiBold}>
          Training Efficiency
        </AppText>
        <Pressable
          style={styles.overviewButton}
          onPress={onOverviewPress}
          hitSlop={6}
          accessibilityRole="button"
          accessibilityLabel="Efficiency overview"
        >
          <AppText style={styles.overviewText} color={Colors.gray600}>
            Overview
          </AppText>
          <Ionicons name="chevron-down" size={12} color={Colors.gray600} />
        </Pressable>
      </View>

      <View style={styles.contentRow}>
        <View style={styles.chartWrapper}>
          <DonutChart
            size={116}
            centerValue={String(totalSessions)}
            centerLabel="TOTAL SESSIONS"
            segments={donutSegments}
          />
        </View>

        <View style={styles.statsContainer}>
          {/* Executed row */}
          <View style={styles.statGroup}>
            <View style={styles.labelRow}>
              <View style={[styles.statusDot, { backgroundColor: "#10B981" }]} />
              <AppText style={styles.statLabel} color={Colors.gray600}>
                Executed
              </AppText>
            </View>
            <AppText style={[styles.statValue, { color: "#10B981" }]} weight={FontWeight.bold}>
              {completed} <AppText style={styles.percentageText} color="#10B981">({executedPercentage}%)</AppText>
            </AppText>
            <View style={styles.progressBarTrack}>
              <View
                style={[
                  styles.progressBarFill,
                  { width: `${Math.max(executedPercentage, 2)}%`, backgroundColor: "#10B981" },
                ]}
              />
            </View>
          </View>

          {/* Pending row */}
          <View style={styles.statGroup}>
            <View style={styles.labelRow}>
              <View style={[styles.statusDot, { backgroundColor: "#2563EB" }]} />
              <AppText style={styles.statLabel} color={Colors.gray600}>
                Pending
              </AppText>
            </View>
            <AppText style={[styles.statValue, { color: "#2563EB" }]} weight={FontWeight.bold}>
              {pending} <AppText style={styles.percentageText} color="#2563EB">({pendingPercentage}%)</AppText>
            </AppText>
            <View style={styles.progressBarTrack}>
              <View
                style={[
                  styles.progressBarFill,
                  { width: `${Math.max(pendingPercentage, 2)}%`, backgroundColor: "#2563EB" },
                ]}
              />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 12,
    ...Shadows.card,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  title: {
    fontSize: Fonts.body,
    color: "#111827",
  },
  overviewButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#F3F4F6",
    borderRadius: Radius.md,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  overviewText: {
    fontSize: 10,
  },
  contentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  chartWrapper: {
    alignItems: "center",
    justifyContent: "center",
  },
  statsContainer: {
    flex: 1,
    gap: 14,
    paddingLeft: 4,
  },
  statGroup: {
    gap: 3,
  },
  labelRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statLabel: {
    fontSize: 11,
  },
  statValue: {
    fontSize: 14,
  },
  percentageText: {
    fontSize: 10,
    fontWeight: "normal",
  },
  progressBarTrack: {
    height: 5,
    backgroundColor: "#F3F4F6",
    borderRadius: 3,
    overflow: "hidden",
    marginTop: 2,
  },
  progressBarFill: {
    height: "100%",
    borderRadius: 3,
  },
});
