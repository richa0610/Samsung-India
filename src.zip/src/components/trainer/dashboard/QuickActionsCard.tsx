import { Pressable, StyleSheet, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import AppText from "@/components/ui/AppText";
import { Colors } from "@/theme/colors";
import { FontWeight } from "@/theme/fontWeight";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";

type QuickActionsCardProps = {
  onCreateTraining: () => void;
  onTrainingList: () => void;
  onViewReports: () => void;
  onAddTrainee: () => void;
};

export default function QuickActionsCard({
  onCreateTraining,
  onTrainingList,
  onViewReports,
  onAddTrainee,
}: QuickActionsCardProps) {
  const actions = [
    {
      key: "create",
      label: "Create New Training",
      iconName: "add-circle" as const,
      iconColor: "#2563EB",
      bgColor: "#EFF6FF",
      onPress: onCreateTraining,
    },
    {
      key: "list",
      label: "Training List",
      iconName: "document-text-outline" as const,
      iconColor: "#10B981",
      bgColor: "#F0FDF4",
      onPress: onTrainingList,
    },
    {
      key: "reports",
      label: "View Reports",
      iconName: "clipboard-outline" as const,
      iconColor: "#F59E0B",
      bgColor: "#FFFBEB",
      onPress: onViewReports,
    },
    {
      key: "add_trainee",
      label: "Add New Trainee",
      iconName: "people-outline" as const,
      iconColor: "#8B5CF6",
      bgColor: "#FAF5FF",
      onPress: onAddTrainee,
    },
  ];

  return (
    <View style={styles.card}>
      <AppText style={styles.title} weight={FontWeight.semiBold}>
        Quick Actions
      </AppText>

      <View style={styles.list}>
        {actions.map((action) => (
          <Pressable
            key={action.key}
            style={[styles.actionRow, { backgroundColor: action.bgColor }]}
            onPress={action.onPress}
          >
            <Ionicons
              name={action.iconName}
              size={15}
              color={action.iconColor}
            />
            <AppText
              style={styles.actionLabel}
              weight={FontWeight.medium}
              numberOfLines={1}
            >
              {action.label}
            </AppText>
            <Ionicons
              name="chevron-forward"
              size={12}
              color={action.iconColor}
            />
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    padding: 14,
    ...Shadows.card,
  },
  title: {
    fontSize: 12,
    color: "#111827",
    marginBottom: 10,
  },
  list: {
    gap: 6,
  },
  actionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 7,
    paddingHorizontal: 8,
    borderRadius: Radius.md,
  },
  actionLabel: {
    flex: 1,
    fontSize: 10,
    color: "#1F2937",
  },
});
