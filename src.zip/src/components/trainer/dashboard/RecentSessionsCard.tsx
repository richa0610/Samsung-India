import { Pressable, StyleSheet, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import AppText from "@/components/ui/AppText";
import { TrainingAgendaItem } from "@/api/training";
import { formatSessionTime, getSessionStatusInfo } from "./dashboardUtils";
import { Colors } from "@/theme/colors";
import { Fonts } from "@/theme/fonts";
import { FontWeight } from "@/theme/fontWeight";
import { Radius } from "@/theme/radius";
import { Shadows } from "@/theme/shadows";

type RecentSessionsCardProps = {
  sessions: TrainingAgendaItem[];
  onViewAll: () => void;
  onSelectSession: (conferenceUid: string) => void;
};

export default function RecentSessionsCard({
  sessions,
  onViewAll,
  onSelectSession,
}: RecentSessionsCardProps) {
  const displaySessions = sessions.slice(0, 2);

  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <AppText style={styles.title} weight={FontWeight.semiBold}>
          Recent Sessions
        </AppText>
        <Pressable
          style={styles.viewAllButton}
          onPress={onViewAll}
          hitSlop={6}
          accessibilityRole="button"
          accessibilityLabel="View all sessions"
        >
          <AppText style={styles.viewAllText} color={Colors.gray600}>
            View All
          </AppText>
        </Pressable>
      </View>

      {displaySessions.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="calendar-outline" size={24} color={Colors.gray400} />
          <AppText style={styles.emptyText} color={Colors.gray400}>
            No recent sessions
          </AppText>
        </View>
      ) : (
        <View style={styles.list}>
          {displaySessions.map((session, index) => {
            const statusInfo = getSessionStatusInfo(session.conferenceStatus);
            const isCompleted = session.conferenceStatus === "Completed";

            return (
              <View key={session.conferenceUid}>
                {index > 0 && <View style={styles.divider} />}
                <Pressable
                  style={styles.sessionItem}
                  onPress={() => onSelectSession(session.conferenceUid)}
                >
                  <View style={styles.iconBox}>
                    <Ionicons
                      name="calendar-outline"
                      size={18}
                      color={isCompleted ? "#10B981" : "#2563EB"}
                    />
                  </View>

                  <View style={styles.sessionDetails}>
                    <AppText
                      style={styles.sessionTitle}
                      weight={FontWeight.medium}
                      numberOfLines={1}
                    >
                      {session.title}
                    </AppText>
                    <AppText
                      style={styles.sessionTime}
                      color={Colors.gray400}
                      numberOfLines={1}
                    >
                      {formatSessionTime(
                        session.conferenceDate,
                        session.conferenceTime
                      )}
                    </AppText>
                  </View>

                  <View
                    style={[
                      styles.statusBadge,
                      { backgroundColor: statusInfo.bg },
                    ]}
                  >
                    <AppText
                      style={[styles.statusText, { color: statusInfo.color }]}
                      weight={FontWeight.medium}
                    >
                      {statusInfo.label}
                    </AppText>
                  </View>
                </Pressable>
              </View>
            );
          })}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    padding: 14,
    ...Shadows.card,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  title: {
    fontSize: 12,
    color: "#111827",
  },
  viewAllButton: {
    backgroundColor: "#F3F4F6",
    borderRadius: Radius.sm,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  viewAllText: {
    fontSize: 9,
  },
  list: {
    gap: 8,
  },
  sessionItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 4,
  },
  iconBox: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    justifyContent: "center",
  },
  sessionDetails: {
    flex: 1,
    gap: 2,
  },
  sessionTitle: {
    fontSize: 11,
    color: "#111827",
  },
  sessionTime: {
    fontSize: 9,
  },
  statusBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: Radius.sm,
  },
  statusText: {
    fontSize: 8,
  },
  divider: {
    height: 1,
    backgroundColor: "#F3F4F6",
    marginVertical: 4,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 18,
    gap: 4,
  },
  emptyText: {
    fontSize: 10,
  },
});
