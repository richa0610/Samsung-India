import { Ionicons } from "@expo/vector-icons";
import { Image, Pressable, StyleSheet, View } from "react-native";

import AppText from "@/components/ui/AppText";
import ScreenBanner from "@/components/ui/ScreenBanner";
import { Colors } from "@/theme/colors";
import { FontWeight } from "@/theme/fontWeight";
import { Shadows } from "@/theme/shadows";

type DashboardHeaderProps = {
  name: string;
  avatarUri?: string | null;
  onOpenProfile: () => void;
  onLogout: () => void;
};

export default function DashboardHeader({
  name,
  avatarUri,
  onOpenProfile,
  onLogout,
}: DashboardHeaderProps) {
  return (
    <ScreenBanner backgroundColor={Colors.mainColour1} style={styles.banner}>
      <View style={styles.topRow}>
        <Pressable
          style={styles.avatarWrapper}
          onPress={onOpenProfile}
          hitSlop={6}
          accessibilityRole="button"
          accessibilityLabel="Account settings"
        >
          <Image
            source={
              avatarUri
                ? { uri: avatarUri }
                : require("@/assets/images/Icons/face_icon.png")
            }
            style={styles.avatarImage}
            resizeMode="cover"
          />
          <View style={styles.avatarOnlineBadge} />
        </Pressable>

        <Pressable
          style={styles.powerButton}
          onPress={onLogout}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel="Logout"
        >
          <Ionicons name="power" size={24} color={Colors.mainColour1} />
        </Pressable>
      </View>

      <View style={styles.welcomeSection}>
        <AppText style={styles.welcomeGreeting} color={Colors.white}>
          Welcome Back,
        </AppText>
        <AppText
          style={styles.welcomeName}
          color={Colors.white}
          weight={FontWeight.bold}
        >
          {name}
        </AppText>
      </View>
    </ScreenBanner>
  );
}

const styles = StyleSheet.create({
  banner: {
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 24,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  avatarWrapper: {
    position: "relative",
    width: 60,
    height: 60,
  },
  avatarImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  avatarOnlineBadge: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: "#22C55E",
    borderWidth: 2.5,
    borderColor: Colors.mainColour1,
  },
  powerButton: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: Colors.white,
    alignItems: "center",
    justifyContent: "center",
    ...Shadows.card,
  },
  welcomeSection: {
    marginTop: 22,
  },
  welcomeGreeting: {
    fontSize: 16,
    lineHeight: 22,
    opacity: 0.95,
  },
  welcomeName: {
    fontSize: 26,
    lineHeight: 32,
    marginTop: 2,
  },
});
